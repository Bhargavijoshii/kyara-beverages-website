window.addEventListener("DOMContentLoaded", () => {
  // ✅ Navbar toggle
  const toggleBtn = document.getElementById("menu-btn");
  const navLinks = document.getElementById("nav-links");

  if (toggleBtn && navLinks) {
    toggleBtn.addEventListener("click", () => {
      navLinks.classList.toggle("hidden");
    });
  }

  // ✅ Scroll animation
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("opacity-100", "translate-y-0");
        entry.target.classList.remove("opacity-0", "translate-y-10");
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll(".fade-section").forEach((section) => {
    section.classList.add("opacity-0", "translate-y-10", "transition-all", "duration-700");
    observer.observe(section);
  });

  // ✅ Contact form submission
  const contactForm = document.getElementById("contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Thank you for reaching out! We'll get back to you soon.");
      contactForm.reset();
    });
  }
});
